 $(document).ready(function(){
 	//flyFiStyle
    $("#flyFiIcon").hover(function(){
        $(".overlayFlyFi").css({"display": "block"});
        $("#smileyIcon,#legRoomIcon,#snacksIcon,#awardIcon,.headerTitle").css({"display": "none"});
        }, function(){
        $(".overlayFlyFi").css({"display": "none"});
        $("#smileyIcon,#legRoomIcon,#snacksIcon,#awardIcon,.headerTitle").css({"display": "block"});
    });
});

 $(document).ready(function(){
    $("#smileyIcon").hover(function(){
        $(".overlaySmiley").css({"display": "block"});
        $("#flyFiIcon,#legRoomIcon,#snacksIcon,#awardIcon,.headerTitle").css({"display": "none"});
        }, function(){
        $(".overlaySmiley").css({"display": "none"});
        $("#flyFiIcon,#legRoomIcon,#snacksIcon,#awardIcon,.headerTitle").css({"display": "block"});
    });
});

 $(document).ready(function(){
    $("#legRoomIcon").hover(function(){
        $(".overlayLegRoom").css({"display": "block"});
        $("#flyFiIcon,#smileyIcon,#snacksIcon,#awardIcon,.headerTitle").css({"display": "none"});
        }, function(){
        $(".overlayLegRoom").css({"display": "none"});
        $("#flyFiIcon,#smileyIcon,#snacksIcon,#awardIcon,.headerTitle").css({"display": "block"});
    });
});

  $(document).ready(function(){
    $("#snacksIcon").hover(function(){
        $(".overlaySnacks").css({"display": "block"});
        $("#flyFiIcon,#smileyIcon,#legRoomIcon,#awardIcon,.headerTitle").css({"display": "none"});
        }, function(){
        $(".overlaySnacks").css({"display": "none"});
        $("#flyFiIcon,#smileyIcon,#legRoomIcon,#awardIcon,.headerTitle").css({"display": "block"});
    });
});

   $(document).ready(function(){
    $("#awardIcon").hover(function(){
        $(".overlayAward").css({"display": "block"});
        $("#flyFiIcon,#smileyIcon,#snacksIcon,#legRoomIcon,.headerTitle").css({"display": "none"});
        }, function(){
        $(".overlayAward").css({"display": "none"});
        $("#flyFiIcon,#smileyIcon,#snacksIcon,#legRoomIcon,.headerTitle").css({"display": "block"});
    });
});