/*Control of elements in the small banner
on right side of Flight Select*/
$(document).ready(function () {
/*	$('#flyFiIcon, #snacksIcon, #awardIcon, #smileyIcon, #legRoomIcon, #awardIcon').mouseover( function(){
    	$('#dropDown').slideDown();
    	console.log('mouseOver:::::');
	})
	$('#flyFiIcon').mouseleave( function(){
	    $('#dropDown').slideUp();
	});
*/
	/*$('#flyFiIcon, #snacksIcon, #awardIcon, #smileyIcon, #legRoomIcon, #awardIcon').hover(function(a,b){
    	$('#dropDown').slideDown();
    	console.log('hover:::::');
	})*/
});
